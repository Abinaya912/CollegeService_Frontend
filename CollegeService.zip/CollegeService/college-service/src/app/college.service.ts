import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CollegeService {
  API="http://localhost:8080";
  public registerCollege(collegeData: any)
  {
    return this.http.post(this.API + '/registerCollege' , collegeData);
  }

  public getColleges(){
    return this.http.get(this.API+'/getCollege');
  }

  public deleteCollege(C_id:any){
    return this.http.delete(this.API+'/deleteCollege?C_id=' + C_id);
  }

  public updateCollege(college: any){
    return this.http.put(this.API +'/updateCollege', college);
  }
  constructor(private http: HttpClient) { }
}
